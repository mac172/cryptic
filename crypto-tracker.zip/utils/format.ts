export function formatNumber(num: number, maximumFractionDigits: number = 2): string {
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits,
  }).format(num)
}

export function formatCurrency(num: number, maximumFractionDigits: number = 2): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits,
  }).format(num)
}

export function formatPercentage(num: number): string {
  return `${num > 0 ? '+' : ''}${num.toFixed(2)}%`
}

export function formatCompactNumber(num: number): string {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 2,
  }).format(num)
}

