import { Suspense } from 'react'
import { MarketOverview } from '@/components/market-overview'
import { CryptoTable } from '@/components/crypto-table'
import { Search } from '@/components/search'
import { getTopCryptos } from '@/actions/crypto'

export default async function Home() {
  const cryptos = await getTopCryptos()

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <h1 className="text-3xl font-bold">Crypto Market</h1>
          <div className="w-full md:w-[300px]">
            <Search cryptos={cryptos} />
          </div>
        </div>

        <Suspense fallback={<div>Loading market data...</div>}>
          <MarketOverview />
        </Suspense>

        <Suspense fallback={<div>Loading crypto assets...</div>}>
          <CryptoTable initialData={cryptos} />
        </Suspense>
      </div>
    </div>
  )
}

