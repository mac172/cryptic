'use server'

import { CryptoAsset, MarketData, CryptoDetail } from '../types/crypto'

const COINGECKO_API = 'https://api.coingecko.com/api/v3'

export async function getTopCryptos(page: number = 1, perPage: number = 20): Promise<CryptoAsset[]> {
  const response = await fetch(
    `${COINGECKO_API}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${perPage}&page=${page}&sparkline=true`
  )

  if (!response.ok) {
    throw new Error('Failed to fetch crypto data')
  }

  return response.json()
}

export async function getGlobalMarketData(): Promise<MarketData> {
  const response = await fetch(`${COINGECKO_API}/global`)
  
  if (!response.ok) {
    throw new Error('Failed to fetch market data')
  }

  const data = await response.json()
  return data.data
}

export async function getCryptoDetail(id: string): Promise<CryptoDetail> {
  const response = await fetch(
    `${COINGECKO_API}/coins/${id}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`
  )

  if (!response.ok) {
    throw new Error('Failed to fetch crypto detail')
  }

  return response.json()
}

