'use client'

import { ArrowUp, ArrowDown, DollarSign, BarChart2, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { CryptoDetail } from '../types/crypto'
import { formatCurrency, formatPercentage } from '../utils/format'
import Image from 'next/image'

interface CoinDetailsProps {
  data: CryptoDetail
}

export function CoinDetails({ data }: CoinDetailsProps) {
  const priceChange24h = data.market_data.price_change_percentage_24h
  const isPriceUp = priceChange24h > 0

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Image
          src={data.image.large}
          alt={data.name}
          width={64}
          height={64}
          className="rounded-full"
        />
        <div>
          <h1 className="text-3xl font-bold">{data.name}</h1>
          <p className="text-xl text-muted-foreground">{data.symbol.toUpperCase()}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-3xl font-bold">
            {formatCurrency(data.market_data.current_price.usd)}
          </span>
          <span
            className={`flex items-center ${
              isPriceUp ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {isPriceUp ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
            {formatPercentage(priceChange24h)}
          </span>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-card hover:bg-card/80 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Market Cap</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(data.market_data.market_cap.usd)}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card hover:bg-card/80 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h Trading Vol</CardTitle>
            <BarChart2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(data.market_data.total_volume.usd)}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card hover:bg-card/80 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h Range</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(data.market_data.low_24h.usd)} - {formatCurrency(data.market_data.high_24h.usd)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card">
        <CardHeader>
          <CardTitle>About {data.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            className="prose prose-invert max-w-none"
            dangerouslySetInnerHTML={{ __html: data.description.en }}
          />
        </CardContent>
      </Card>
    </div>
  )
}

