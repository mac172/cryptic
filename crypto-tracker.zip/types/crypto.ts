export interface CryptoAsset {
  id: string
  symbol: string
  name: string
  image: string
  current_price: number
  market_cap: number
  market_cap_rank: number
  price_change_percentage_24h: number
  price_change_percentage_7d: number
  total_volume: number
  sparkline_in_7d: {
    price: number[]
  }
}

export interface MarketData {
  total_market_cap: { usd: number }
  total_volume: { usd: number }
  market_cap_percentage: {
    btc: number
    eth: number
  }
}

export interface CryptoDetail {
  id: string
  symbol: string
  name: string
  description: { en: string }
  image: { large: string }
  market_data: {
    current_price: { usd: number }
    price_change_percentage_24h: number
    price_change_percentage_7d: number
    market_cap: { usd: number }
    total_volume: { usd: number }
    high_24h: { usd: number }
    low_24h: { usd: number }
  }
}

